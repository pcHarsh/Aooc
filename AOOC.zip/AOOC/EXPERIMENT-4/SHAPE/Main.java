public class Main{
    public static void main(String[] args){
        Rectangle rect = new Rectangle(4,4);
        Triangle tri = new Triangle(7,13);

        System.out.println("Area of the Rectangle is: " + rect.area());
        System.out.println("Area of the Triangle is: " + tri.area());
    }
}
