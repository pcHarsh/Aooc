interface Shape{
    double area();
}
