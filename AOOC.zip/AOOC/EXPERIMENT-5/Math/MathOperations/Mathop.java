package MathOperations;

public class Mathop{
    public void operations(double number){
        System.out.println("Original Number: " + number);
        System.out.println("Floor: " + Math.floor(number));
        System.out.println("Ceil: " + Math.ceil(number));
        System.out.println("Round: " + Math.round(number));
    }
}
